package ExceptionalHandling;

class InvalidAgeException extends Exception {
	
}

class UserRegisteration {
	
	void register(int age) {
		if(age<18) {
			try {

				throw new InvalidAgeException();
				
			} catch (InvalidAgeException e) {
				System.out.println("user is a minor");
			}
			else {
				System.out.println("Successfully Registered...");
			}
		}
	}
}

public class Handling {

	public static void main(String[] args) {
		UserRegisteration user = new UserRegisteration();
        user.register(13);
	}

}
