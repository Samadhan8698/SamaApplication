package ExceptionalHandling;

class InvalidAgeException extends Exception {
	
}
class UserRegisteration {
	void register(int age) throws InvalidAgeException {
		if(age<18) {
			throw new InvalidAgeException();
			
		}
		
		else {
			System.out.println("Successfully Registered..");
		}
	}
}
public class Handling2 {

	public static void main(String[] args) {
		UserRegisteration user = new UserRegistration();
		try {
			user.register(13);
		} catch (InvalidAgeException e) {
			System.out.println("user is a minor..");
		}

	}

}
