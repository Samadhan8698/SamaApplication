package Array_variation;

public class sum_of_oddfactors {

	public static void main(String[] args) {

		int n = 30;
		int count = 0;
		int add = 0;
		for (int i = 1; i < n; i++) {
			if (n % i == 0) {
				count++;

			}
			if (count > 0) {
				if (i % 2 != 0) {
					add += i;

				}
				count = 0;

			}
		}
		System.out.println(add);
	}

}
