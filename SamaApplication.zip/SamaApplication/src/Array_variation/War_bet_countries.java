package Array_variation;

public class War_bet_countries {

	public static void main(String[] args) {
		
		int[] a= {11,33,44,66};
		int[] b= {11,33,44,66};
		
		int acount=0;
		int bcount=0;
		for(int i=0;i<a.length;i++) {
			
			if(a[i]>b[i]) {
				acount++;
			}
			else if(b[i]>a[i]) {
				bcount++;
			}
		}
		
		if(acount>bcount) {
			System.out.println("A wins");
		}
		else if(bcount>acount) {
			System.out.println("B wins");
		}
		else {
			System.out.println("Tie");
		}

	}

}
