package Exception_Handling2;

public class Exception_basic2 {

	public static void main(String[] args) {
		
		
		// Arithmatic Exception
		
//		System.out.println(10/0);
		
		// NullPointerException
		
		String s1=null;
		System.out.println(s1.toLowerCase());

	}

}
