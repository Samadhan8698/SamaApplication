package Exception_Handling2;

public class basic_exception {

	public static void main(String[] args) {
		
		System.out.println("Reg");
		System.out.println("Log");
		System.out.println("Search/cat");
		System.out.println("Select product"+10/0); // unwanted unexpected
		System.out.println("payment");
		System.out.println("CHECK OUT");

	}

}
