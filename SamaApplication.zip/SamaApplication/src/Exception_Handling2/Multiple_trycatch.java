package Exception_Handling2;

public class Multiple_trycatch {

	public static void main(String[] args) {
		
		try {
			int[] num = {1,2,3};
			System.out.println(num[9]);
		}catch(ArrayIndexOutOfBoundsException e) {
			
			System.out.println(e);
		}
		
		try {
			System.out.println(10/0);
		}catch(ArithmeticException e) {
			System.out.println(e);
		}
		
		try {
			String s1 = null;
			System.out.println(s1.toLowerCase());
		}catch(Exception e) {
			System.out.println(e);
		}

	}

}
