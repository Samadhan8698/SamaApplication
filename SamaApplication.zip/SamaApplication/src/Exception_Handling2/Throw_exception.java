package Exception_Handling2;

public class Throw_exception {

	public static void main(String[] args) {
		
		try {
			
			throw new AgeLimitException("Age is less than 18");
		}catch(AgeLimitException e) {
			System.out.println(e);
		}
		
		System.out.println("Done");

	}

}

class AgeLimitException extends Exception {
	public AgeLimitException(String msg) {
		super(msg);
	}
}
