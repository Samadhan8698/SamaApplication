package Exception_Handling2;

public class TryCatch_basic {

	public static void main(String[] args) {
		
		
		
		System.out.println("Log in");
		
		try {
			System.out.println("Browse"+10/0);
		}catch(Exception e) {
			
			System.out.println("Do not divide no by 10"+e);
			
		}
		
		System.out.println("Add to cart");
		System.out.println("pay");
		System.out.println("log out");

	}

}
