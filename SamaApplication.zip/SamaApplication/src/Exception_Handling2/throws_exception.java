package Exception_Handling2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.channels.AlreadyBoundException;
import java.rmi.AccessException;

// throws keyword is used when we doesn't want to handle the exception 
// and try to send the exception to other method (person who will create 
// the object of that particular class

public class throws_exception {

	public static void main(String[] args) {
		
		ReadAndWrite rw = new ReadAndWrite();
		try {
			rw.read();
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}
}
		class ReadAndWrite {
			
			public void read()throws FileNotFoundException,AccessException,AlreadyBoundException {
				FileInputStream f1 = new FileInputStream("D:/Hefshine/Demo.txt");
			}
		}

	


