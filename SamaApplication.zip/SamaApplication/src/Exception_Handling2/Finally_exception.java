package Exception_Handling2;

public class Finally_exception {

	public static void main(String[] args) {
		
		
		System.out.println("open mysql connections");

		try {
			System.out.println("processing"+10/0);
		}catch(Exception e) {
			System.out.println(e);
		}finally {
			System.out.println("close MySQL");
		}
	}

}
