package Exception_Handling2;

public class Nested_trycatch {

	public static void main(String[] args) {
		
		
		try {
			
			try {
				int[] num = {1,2,3};
				System.out.println(num[9]);
				
			}catch(ArrayIndexOutOfBoundsException e) {
				
				System.out.println(e);
			}
			
			System.out.println(10/0);
			
			
		}catch(Exception e) {
		
		
		System.out.println(e);

	}

	}
}
