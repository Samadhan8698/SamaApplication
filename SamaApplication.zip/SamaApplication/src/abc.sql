select cols
from table1
inner join table2
on table.id=table2.id;

select cols
from table1
inner join table2
on table.id=table2.id;

where salary > 10000;


Q.write a query to find name (first_name,last_name),job,DEPARTMENT_ID and name of the employees who works in londan

1.employees
EMPLOYEE_ID | FIRST_NAME  | LAST_NAME   | EMAIL    | PHONE_NUMBER  | HIRE_DATE  | JOB_ID     | SALARY    | COMMISSION_PCT | MANAGER_ID | DEPARTMENT_ID
2.depart
DEPARTMENT_ID | DEPARTMENT_NAME      | MANAGER_ID | LOCATION_ID
3.jobs
 JOB_ID   | JOB_TITLE   | MIN_SALARY | MAX_SALARY
 4.locations
 LOCATION_ID | STREET_ADDRESS | POSTAL_CODE  | CITY   | STATE_PROVINCE    | COUNTRY_ID

 select employees.first_name,
 employees.last_name,
 jobs.JOB_TITLE,
 depart.DEPARTMENT_ID,
 depart.DEPARTMENT_NAME,
 locations.CITY
 from employees
 inner join depart on employees.DEPARTMENT_ID=depart.DEPARTMENT_ID
 inner join jobs on jobs.JOB_ID=employees.JOB_ID
 inner join locations on locations.LOCATION_ID=depart.LOCATION_ID
 where locations.CITY='London';

 Q.write a query to display the DEPARTMENT_NAME,manager id,and city.

 select depart.DEPARTMENT_NAME,employees.first_name,locations.city
 from employees
 inner join depart on depart.MANAGER_ID=employees.MANAGER_ID
 inner join locations on depart.LOCATION_ID=locations.LOCATION_ID;

 Q.write a query to display department name,department manager (first_name,last_name),
 hire date of manager,
 salary of the manager for those managers whose experiance is more than 15 years.


 select 
 depart.DEPARTMENT_NAME,
 employees.first_name,
 employees.last_name,
 employees.salary
 from employees
 inner join depart on depart.MANAGER_ID=employees.EMPLOYEE_ID
 where datediff(NOW(),employees.HIRE_DATE) > (15*365);
 