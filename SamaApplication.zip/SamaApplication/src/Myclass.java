
public class MyClass
{
	public static void main(String[] args) 
	{
		//meth.4
		 int range = 20;
	     System.out.print(sumOfNaturalNumbers(range)); 
	}

	private static int sumOfNaturalNumbers(int range)
    {
        int sum = 0;
        if (range == 1)
            return 1;
        sum = range + sumOfNaturalNumbers(range - 1);
        return sum;
    }
}

