package Stack_vector;

import java.util.Stack;
import java.util.Vector;

public class stack_basic {

	public static void main(String[] args) {
		
		Stack sc = new Stack();
		sc.add(10);
		sc.add(20);
		sc.add(30);
		
		System.out.println(sc);
		sc.pop();
		System.out.println(sc);
		
		Vector v = new Vector();
		v.add(10);
		v.add(20);
		v.add(30);
		
		System.out.println(v);
		// synchronization -> single threaded
		// Stack and vector are slow as compare to other classes in list interfaces
		
		

	}

}
