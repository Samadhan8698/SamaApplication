package Stack_vector;

import java.util.ArrayList;
import java.util.HashSet;

public class Diff_arrlist_hashset {

	public static void main(String[] args) {
		
HashSet <Integer> hs = new HashSet();
		
		hs.add(20);
		hs.add(30);
		hs.add(30);
		hs.add(40);
		hs.add(50);
		
		// follow insertion order
		
		System.out.println("ArrayList : "+hs);
		
		ArrayList List1 = new ArrayList();
		List1.add(20);
		List1.add(30);
		List1.add(30);
		List1.add(40);
		List1.add(50);
		
		// doesn't allow duplicate
		
		System.out.println("HashSet : "+List1);
		

	}

}
