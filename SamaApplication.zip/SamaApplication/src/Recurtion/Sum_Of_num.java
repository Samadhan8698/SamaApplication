package Recurtion;

public class Sum_Of_num {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=8;
		int x=print(num);
		System.out.println(x);// calling of function
//		System.out.println(print(num));

	}
	public static int print(int num) {
		if(num>0) {
			return num+print(num-1);
		}
		else {
			return 0;
		}
	}

}
