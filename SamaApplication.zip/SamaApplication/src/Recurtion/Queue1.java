package Recurtion;
import java.util.*;

public class Queue1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue <Integer> p1=new PriorityQueue<Integer>();
		p1.add(1);
		p1.add(888);
		p1.add(3333);
		p1.add(55);
		p1.offer(22);
		p1.add(45);
		p1.add(23);
		p1.add(4988);
		System.out.println(p1);

	}

}
