package Recurtion;

import java.util.PriorityQueue;

public class Method_queue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue <Integer> p1 = new PriorityQueue <Integer>();
		
		p1.add(1);
		p1.add(2);
		p1.add(3);
		p1.add(4);
		p1.add(5);
		
		System.out.println(p1);
		
		p1.poll();
		System.out.println(p1);
		p1.poll();
		System.out.println(p1);

	}

}
