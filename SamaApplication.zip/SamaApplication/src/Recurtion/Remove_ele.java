package Recurtion;

public class Remove_ele {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Priority

	}

}
