package Recurtion;

import java.util.PriorityQueue;

public class Queue23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PriorityQueue <Integer> p1 = new PriorityQueue <Integer>();
        p1.add(1);
        p1.add(2);
        p1.add(1);
        p1.add(2);
        p1.offer(4);
        p1.add(3);
//        System.out.println(p1);
       // p1.clear();
        
        System.out.println(p1.element()); // gives error if empty
//        System.out.println(p1.peek()); // if empty pass null
	}

}
