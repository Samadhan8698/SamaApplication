package tree_set;

import java.util.TreeSet;

public class add_ele {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
TreeSet t1 = new TreeSet();
		
		t1.add(2);
		t1.add(1);
		t1.add(5);
		t1.add(3);
		t1.add(6);
		t1.add(10);
		t1.add(9);
		
		System.out.println(t1);
		
		TreeSet t12 = new TreeSet();
		t12.addAll(t1);
		
		System.out.println(t12);
		
		// retrieve and remove
		System.out.println(t1.pollFirst());
		System.out.println(t1);
		
		System.out.println(t1.first());
		System.out.println(t1);
		
		
	}

}
