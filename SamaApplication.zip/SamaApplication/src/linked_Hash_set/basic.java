package linked_Hash_set;

import java.util.LinkedHashSet;

public class basic {
	
	// maintain the insertion order (As it follow the principle of linked list
	// repetition of element not allowed

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedHashSet<Integer> s = new 	LinkedHashSet<Integer>();
		s.add(50);
		s.add(10);
		s.add(20);
		s.add(10);
		
		System.out.println(s);
	}

}
