package Array;

import java.util.Scanner;

public class Practicearray {

	public static void main(String[] args) {
		// array is a sequential collection of similar data type
	//	collection of similar data type store at contiguos memory location
// we can have data of array on the basis of index number 
		
		// advantages of array:
//		1) code optimisation
//        2) easy to traversing
//        3) easy to sorting
//        4) random access
		
		int a[]= new int[5];
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter 5 element: ");
		for(int i=0;i<a.length;i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("array : ");
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i] + " ");
		}

	}

}
