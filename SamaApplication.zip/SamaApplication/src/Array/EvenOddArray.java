package Array;

public class EvenOddArray {

	public static void main(String[] args) {
		int arr[] = {1,2,3,4,45,24,8,9};
 		int eCount=0; int oddCount = 0;
		
		for(int i=0;i<arr.length;i++) {
			if(arr[i]%2==0) {
				eCount++;
			}
			else {
				oddCount++;
			}
		}
		int[]even =new int[eCount];
		int[]odd = new int[oddCount];
		
		int iE=0; int iO = 0;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]%2==0) {
				even[iE]=arr[i];
				iE++;
			}
			else {
			
			
				odd[iO]=arr[i];
			
				iO++;
			}
		}
		
		for(int num : even) {
			System.out.print(num + " ");
		}
		System.out.println("\n\n");
		for(int num : odd) {
		   System.out.print(num + " ");
		}
		

	}

}
