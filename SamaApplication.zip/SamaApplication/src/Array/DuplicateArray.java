package Array;

public class DuplicateArray {

	public static void main(String[] args) {
		int[][] a= {{2,4,4},{5,8,9},{3,6,8}};
		int[][] b= {{9,5,7},{9,4,2},{2,7,5}};
		
		int[][] c=new int[a.length][b.length];
		
		for(int i=0;i<a.length;i++) {
		
			 for(int j=0;j<b.length;j++) {
				
			c[i][j]=a[i][j]+b[i][j];		  
		
			 
			 System.out.print(c[i][j]+" ");
			 }
			 
			 System.out.println();
		}
//		for(int i=0;i<c.length;i++) {
//		
//			 for(int j=0;j<c.length;j++) {
//				
//				   System.out.print(c[i][j]+" ");
//			 }
			 
		}

	}


