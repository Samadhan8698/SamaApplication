package Array;

public class AlternateElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a= {1,2,3,4};
		
		for(int i=0;i<a.length;i++) {
			if(i%2==0) {
				System.out.println(i);
			}
			
		}

	}

}
