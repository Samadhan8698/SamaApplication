package Array;

public class SearchElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1=new String("11001");
		int d=Integer.parseInt(s1,8);
		
		System.out.println(d);
		
		
	  
		

	}

}
