package Hash_set1;

import java.util.HashSet;

public class retains_data {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashSet<String> h1 = new HashSet<String>();
		h1.add("abc");
		h1.add("xyz");
		h1.add("ghh");
		
		System.out.println(h1);
		
		HashSet<String> h2 = new HashSet<String>();
		h2.add("abc");
		h2.add("xmn");
		h2.add("ghh");
		
		System.out.println(h2);
		h1.retainAll(h2);
		System.out.println(h1);

	}

}
