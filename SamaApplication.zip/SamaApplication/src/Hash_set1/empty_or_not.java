package Hash_set1;

import java.util.HashSet;

public class empty_or_not {

	public static void main(String[] args) {
	

		HashSet hs = new HashSet();
		
		hs.add(10);
		hs.add(20);
		
		// hash set empty or not
		System.out.println(hs.isEmpty());
		
		
		// to get the number of element 
		System.out.println(hs.size());
		
	}

}
