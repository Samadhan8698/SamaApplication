package Hash_set1;

import java.util.HashSet;

public class basic_set {

	public static void main(String[] args) {
		
		
		HashSet<Integer> h1 = new HashSet<Integer>();
		h1.add(10);
		h1.add(50);
		h1.add(22);
		h1.add(3);
		h1.add(50);
		System.out.println(h1);

	}

}
