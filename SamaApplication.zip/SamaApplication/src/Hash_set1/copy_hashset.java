package Hash_set1;

import java.util.HashSet;

public class copy_hashset {

	public static void main(String[] args) {
		

		HashSet<Integer> h1 = new HashSet<Integer>();
		h1.add(10);
		h1.add(50);
		h1.add(22);
		h1.add(3);
		h1.add(50);
		System.out.println(h1);
		
		HashSet<Integer> h2 = new HashSet<Integer>();
		h2.addAll(h1);
		System.out.println(h2);
		System.out.println("size : "+h1.size());
		System.out.println(h1.isEmpty());
//		h1.clear();
		h1.removeAll(h1);
		System.out.println(h1);
	}

}
