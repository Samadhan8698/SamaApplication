package Array_List;

import java.util.ArrayList;

public class insert_ele_first {

	public static void main(String[] args) {
		
		
ArrayList<Integer> al = new ArrayList<Integer>();
		
		al.add(10);
		al.add(20);
		al.add(30);
		al.add(40);
		al.add(50);
		//al.add(100);
	//	al.addFirst(100);
		al.addLast(90);
		System.out.println(al);
		System.out.println(al.get(2)); // retrive element
	}

}
