package Array_List;
import java.util.*;

public class compare_twoArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<String> al = new ArrayList<String>();
		al.add("Red");
		al.add("Blue");
		al.add("Orange");
		al.add("Black");
		
		System.out.println(al);
		
		ArrayList<String> al2 = new ArrayList<String>();
		al2.add("Red");
		al2.add("Blue");
		al2.add("Orange");
		al2.add("Black");
		
		System.out.println(al2);
		
		System.out.println(al.equals(al2));
		
		

	}

}
