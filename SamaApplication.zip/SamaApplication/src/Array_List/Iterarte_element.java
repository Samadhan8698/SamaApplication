package Array_List;

import java.util.*;

public class Iterarte_element {

	public static void main(String[] args) {
		
		ArrayList<String> al = new ArrayList<String>();
		al.add("Red");
		al.add("blue");
		al.add("Black");
		al.add("Orange");
		
		System.out.println(al);
		
	Iterator<String> i=al.listIterator(0);
	
	while(i.hasNext()) {
		
		System.out.println(i.next());
	}
	
	System.out.println(al.getClass());
	
		

	}

}
