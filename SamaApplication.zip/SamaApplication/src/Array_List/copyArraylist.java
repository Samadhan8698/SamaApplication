package Array_List;

import java.util.ArrayList;

public class copyArraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

ArrayList<Integer> al = new ArrayList<Integer>();
		
		al.add(10);
		al.add(20);
		al.add(30);
		al.add(40);
		al.add(50);
		
		System.out.println("source : "+al);
		
		ArrayList<Integer> al2 = new ArrayList<Integer>(al);
		
		System.out.println("destination : "+al2);
	}

}
