package Array_List;
import java.util.*;

//import java.util.ArrayList;
//import java.util.Collections;

public class Sort_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
ArrayList<String> List1 = new ArrayList<String>();
		
		List1.add("x");
		List1.add("y");
		List1.add("z");
		List1.add("a");
		
		System.out.println("List1 : "+List1);
		
		// Ascending
		Collections.sort(List1);
		System.out.println("Ascending :"+List1);
		
		// Descending
		
		Collections.sort(List1,Collections.reverseOrder());
		System.out.println("Descending :"+List1);
		
		

	}

}
