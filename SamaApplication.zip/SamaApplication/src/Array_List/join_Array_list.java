package Array_List;

import java.util.ArrayList;

public class join_Array_list {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
ArrayList<Integer> List1 = new ArrayList<Integer>();
		
		List1.add(10);
		List1.add(20);
		List1.add(30);
		List1.add(40);
		List1.add(50);
		System.out.println("List1 : "+List1);
		
ArrayList<Integer> List2 = new ArrayList<Integer>();
		
		List2.add(33);
		List2.add(22);
		List2.add(34);
		List2.add(44);
		List2.add(55);
		System.out.println("List2 : "+List2);
		
		ArrayList<Integer> List3 = new ArrayList<Integer>();
		List3.addAll(List1);
		List3.addAll(List2);
		System.out.println("List3 : "+List3);
		
		
		
		
		
		

	}

}
