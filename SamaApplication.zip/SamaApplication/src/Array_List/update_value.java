package Array_List;

import java.util.ArrayList;

public class update_value {
	
	// to update element
	// to remove element

	public static void main(String[] args) {
ArrayList<Integer> al = new ArrayList<Integer>();
		
		al.add(10);
		al.add(20);
		al.add(30);
		al.add(40);
		al.add(50);
		System.out.println(al);
		al.set(2, 100);
		System.out.println(al);
		al.remove(3);
		System.out.println(al);

	}

}
