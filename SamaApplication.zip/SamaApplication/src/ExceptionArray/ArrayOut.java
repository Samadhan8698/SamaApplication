package ExceptionArray;

public class ArrayOut {

	public static void main(String[] args) {
		int a[]= new int[5];
		a[0]=34;
		a[1]=66;
		a[2]=88;
		a[3]=65;
		a[4]=99;
		try {
			a[5]=100;
		}
		catch (ArrayIndexOutOfBoundException e) {
			System.out.println("you are accessing elements beyond length of array");
			
		}
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}

	}

}


	


