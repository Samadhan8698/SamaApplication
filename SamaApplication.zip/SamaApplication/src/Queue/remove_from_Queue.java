package Queue;

import java.util.PriorityQueue;

public class remove_from_Queue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PriorityQueue<Integer> p1 = new PriorityQueue<Integer>();
		p1.add(6);
		p1.add(5);
		p1.add(9);
		p1.add(8);
		
		System.out.println(p1);
		System.out.println(p1.poll());
		System.out.println(p1);
	}

}
