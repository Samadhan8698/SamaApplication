package Queue;

import java.util.PriorityQueue;

public class new_prio_queue {

	public static void main(String[] args) {
		
		
		PriorityQueue<Integer> p1 = new PriorityQueue<Integer>();
		p1.offer(18);
		p1.offer(12);
		p1.add(11);
		p1.add(8);
		p1.add(7);
		int ele=100;
		System.out.println(p1);
		
//		System.out.println(p1.peek()); // print first element
		
		System.out.println(p1.poll()); // remove first element from queue
		System.out.println(p1); 
		p1.add(ele);
		System.out.println(p1);
		
		


	}

}
