package Queue;

import java.util.PriorityQueue;

public class copy_pqtoanotherpq {

	public static void main(String[] args) {
	     
		
		PriorityQueue<Integer> p1 = new PriorityQueue<Integer>();
		p1.add(15);
		p1.add(2);
		p1.add(17);
		p1.add(36);
		p1.add(57);
		System.out.println(p1);
		
		PriorityQueue<Integer> p2 = new PriorityQueue<Integer>(p1);
		System.out.println(p2);
		


	}

}
