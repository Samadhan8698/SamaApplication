package Queue;
import java.util.PriorityQueue;

public class alpha_queue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PriorityQueue<String> p1 = new PriorityQueue<String>();
		
		p1.add("abc");
		p1.add("lmn");
		p1.add("xyz");
		
		System.out.println(p1);
		

	}

}
