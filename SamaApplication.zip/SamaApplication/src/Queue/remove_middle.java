package Queue;

import java.util.PriorityQueue;

public class remove_middle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PriorityQueue<Integer> p1 = new PriorityQueue<Integer>();
		p1.add(6);
		p1.add(5);
		p1.add(9);
		p1.add(8);
		
		System.out.println(p1);
		System.out.println(p1.remove(9));
		System.out.println(p1);
		p1.removeAll(p1);
		System.out.println(p1);

	}

}
