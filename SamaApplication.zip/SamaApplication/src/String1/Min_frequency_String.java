package String1;

public class Min_frequency_String {
	public static void main(String[] args) {
		String s1 = "aabbccx";
		int min = Integer.MAX_VALUE;
		char ch = 0;
		for (int i = 0; i < s1.length(); i++) {
			int cnt = 0;
			for (int j = 0; j < i; j++) {
				if (s1.charAt(i) == s1.charAt(j)) {
					cnt++;
				}
			}
			if (cnt == 0) {
				// System.out.println(s1.charAt(i));
				int count = 0;
				for (int j = 0; j < s1.length(); j++) {
					if (s1.charAt(i) == s1.charAt(j)) {
						count++;
					}
				}
				// System.out.println(s1.charAt(i) + " " + count);
				if (count < min) {
					min = count;
					ch = s1.charAt(i);
				}
			}
		}
		System.out.println("minimum frequency : " + min);
		System.out.println(ch);
	}
}
