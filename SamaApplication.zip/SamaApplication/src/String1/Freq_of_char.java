package String1;

public class Freq_of_char {

	public static void main(String[] args) {

		String s1 = "aabbccx";
		int min=Integer.MAX_VALUE;
         
		for (int i = 0; i < s1.length(); i++) {
			int cnt=0;
			for (int j = 0; j < i; j++) {

				if (s1.charAt(i) == s1.charAt(j)) {
					cnt++;
				}
			}

			if (cnt == 0) {
				// System.out.println(s1.charAt(i));
				  int count=0;
				for (int j = 0; j < s1.length(); j++) {

					if (s1.charAt(i) == s1.charAt(j)) {

						count++;
					}

				}

			//	System.out.println(s1.charAt(i) + " " + count);
				if(count<min) {
					min=count;
				}
				

			}
			System.out.println(min);

		}
	}

}
