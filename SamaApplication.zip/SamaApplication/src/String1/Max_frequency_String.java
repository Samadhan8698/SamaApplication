package String1;

public class Max_frequency_String {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		String s1 = "aabbccx";
//		int max = Integer.MIN_VALUE;
//		char ch = 0;
//		for (int i = 0; i < s1.length(); i++) {
//			int cnt = 0;
//			for (int j = 0; j < i; j++) {
//
//				if (s1.charAt(i) == s1.charAt(j)) {
//					cnt++;
//				}
//			}
//			if (cnt == 0) {
//				// System.out.println(s1.charAt(i));
//				int count = 0;
//				for (int j = 0; j < s1.length(); j++) {
//					if (s1.charAt(i) == s1.charAt(j)) {
//						count++;
//					}
//				}
//				// System.out.println(s1.charAt(i) + " " + count);
//				if (count > max) {
//					max = count;
//					ch = s1.charAt(i);
//				}
//			}
//		}
//		System.out.print("maximum frequency : " + max);
//		System.out.println(" " + ch);

		String s1 = "aabbccx";
		int min = Integer.MAX_VALUE;
		char ch = 0;

		for (int i = 0; i < s1.length(); i++) {
			int cnt = 0;
			for (int j = 0; j < i; j++) {
				if (s1.charAt(i) == s1.charAt(j)) {
					cnt++;
				}
			}
			if(cnt==0) {
			
				 int count=0;
				 for(int j=0;j<s1.length();j++) {
					
					 if(s1.charAt(i)==s1.charAt(j)) {
						 count++;
					 }
				 }
				 
				 if(count < min) {
					
					 min=count;
					 ch=s1.charAt(i);
				 }
			}
			}
		System.out.println(min);
		System.out.println(ch);
		
	}

}
