package String1;

public class Reverse_every_word_String {
    public static void main(String[] args) {
		String s1="welcome to hefshine";
		String[] s2=s1.split(" ");
		for(int i=0;i<s2.length;i++) {
				String s3=s2[i];
			char[] ca=s3.toCharArray();
			
			int start=0;
			int end = ca.length-1;
			while(start < end) {
					char temp = ca[start];
				ca[start] = ca[end];
				ca[end]=temp;
				start++;
				end--;
			}
			
			String s4=new String(ca);
			s2[i]=s4;
		}
		
		for(String i : s2) {
			System.out.print(i+" ");
		}
//		System.out.println();
//		System.out.println();
//		String s5="";
//		
//		for(int i=0; i<s2.length;i++) {
//		
//		  	s5=s5+s2[i]+" ";
//		  	
//		  		}	
//		System.out.println(s5);
//
//	}

}
}