package Multi_threading;
 class test12 extends Thread {

	public void run() {
		
		for(int i=0;i<3;i++) {
		
		System.out.println(Thread.currentThread().getName());
		}
	
}
 }

public class demo101 {

	public static void main(String[] args) {

		    test12 t1=new test12();
		    t1.start();
		    t1.setName("thread 1");
		    
		    test12 t2=new test12();
		    t2.start();
		    t2.setName("thread 2");
		    
		    for(int i=0;i<3;i++) {
		    	System.out.println(Thread.currentThread().getName());
		    }
		
		
	
			
			
		}

}
 


