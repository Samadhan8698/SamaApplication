package Multi_threading;


class dd extends Thread {
	
	public void run() {
		System.out.println("hello");
		System.out.println(Thread.currentThread().getPriority());
	}
}

public class priority_thread {

	public static void main(String[] args) {
    
		System.out.println(Thread.currentThread().getPriority());
		Thread.currentThread().setPriority(3);
		System.out.println(Thread.currentThread().getPriority());
		dd d1=new dd();
		d1.start();
		d1.setPriority(Thread.NORM_PRIORITY);
		d1.setPriority(Thread.MAX_PRIORITY);
		d1.setPriority(Thread.MIN_PRIORITY);
		

		
	}

}
