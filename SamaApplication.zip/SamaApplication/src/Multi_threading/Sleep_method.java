package Multi_threading;


class test123 extends Thread {
	
	public void run() {
		
		for(int i=0;i<3;i++) {
			
			try {
				
				Thread.sleep(4000);
				
			} catch (Exception e) {
			
				e.printStackTrace();
			}
			
			System.out.println(Thread.currentThread().getName()); 
			
		}
	}
}

public class Sleep_method {

	public static void main(String[] args) {
		
		
		 test123 t1=new test123();
		    t1.start();
		    t1.setName("thread 1");
		    
		    test123 t2=new test123();
		    t2.start();
		    t2.setName("thread 2");
		    
		    for(int i=0;i<3;i++) {
		    	
		    	
		    	System.out.println(Thread.currentThread().getName());
		    }
		
		
		
		

	}

}
