package Multi_threading;


class myclass2 extends Thread {
	
	   
}

public class Thread_method {

	public static void main(String[] args) {
		

	}

}
