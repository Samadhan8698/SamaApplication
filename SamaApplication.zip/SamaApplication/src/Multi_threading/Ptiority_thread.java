package Multi_threading;


class dd extends Thread {
	
	public void run() {
		
		System.out.println("hello");
		System.out.println(Thread.currentThread().getPriority());
	}
}

public class Ptiority_thread {

	public static void main(String[] args) {
		
		System.out.println(Thread.currentThread().getPriority());
		dd d1=new dd();
		d1.start();
	}

}
