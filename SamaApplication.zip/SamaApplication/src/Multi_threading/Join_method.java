package Multi_threading;

class test1 extends Thread {
	
	public void run() {
	
	for(int i=0;i<3;i++) {
		
		System.out.println(Thread.currentThread().getName());
	}
}
}

public class Join_method {

	public static void main(String[] args) {
		
		test1 t1=new test1();
		t1.start();
		t1.setName("thread 1");
		try {
			
			t1.join();
			
		}
		catch(Exception e) {
			e.printStackTrace();
			
			
		}
		
		test12 t2=new test12();
		t2.start();
		t2.setName("thread 2");
		
		try {
			
			t2.join();
		}
		catch(Exception e) {
			
			e.printStackTrace();
			
		}
		
		for(int i=0;i<3;i++) {
			
			System.out.println(Thread.currentThread().getName());
		}
		
		
		
		

	}

}
