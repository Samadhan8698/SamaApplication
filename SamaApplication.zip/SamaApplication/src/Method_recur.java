
public class Method_recur {
	
	void print(int n) {
	    if(n<1) {
	    	return;
	    }
	    else {
	    	print(n-1);
	    }
	    System.out.println(n);
	}
	

	public static void main(String[] args) {
	
			
		Method_recur a1 = new Method_recur();
		int n=10;
		a1.print(n);

	}

}
