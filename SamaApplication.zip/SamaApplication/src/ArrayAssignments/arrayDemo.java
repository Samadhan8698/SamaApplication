package ArrayAssignments;

public class arrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[]= {11,22,33,44,55,66,77};
	     // index  0  1   2  3  4  5  6
	     
	     for(int i=0;i<a.length;i++) {
	    	 System.out.println(a[i]);
	     }
	}

}
