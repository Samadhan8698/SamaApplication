package coding;

public class NewClass {

	public static void main(String[] args) {
		
		// Exceptional handling

		String s = null;
		try {
			System.out.println(s.length());
		} catch (NullPointerException e) {
			System.out.println("Please give a value in string s");
		}
		System.out.println("bye bye");
	}

}
