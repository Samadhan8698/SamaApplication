package coding;

public class MethodDriver {

	
		public static void main(String[] args) {
		    Method m1=new Method();
		    m1.setCity("Pune");
		    String s=m1.getCity();
		    System.out.println(s);

		}

	}


