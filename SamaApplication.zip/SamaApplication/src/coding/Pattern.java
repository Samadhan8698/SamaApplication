package coding;

public class Pattern {
	public static void main(String[] args) {
		
		int size=6;
		
		for(int i=1,k='A'; i<=size; i++,k++)
		{
			for(int j=1,p=k; j<=i; j++)
			{
				
				System.out.print((char)p);
				p=p+5;
			
			}
		
			System.out.println();
		
		
		}


	}
}
