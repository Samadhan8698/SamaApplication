package coding;
import java.util.*;

public class calculator_project {

	public static void main(String[] args) {
	
          Scanner sc=new Scanner(System.in);
          System.out.println("enter 1st value : ");
          int num1=sc.nextInt();
          
          
          System.out.println("operator : ");
          char operator=sc.next().charAt(0);
          
          System.out.println("enter 2nd value : ");
          int num2=sc.nextInt();
          
          if(operator=='+') {
        	 System.out.println(num1+num2); 
          }
          else if(operator=='-') {
        	  
        	  System.out.println(num1-num2);
          }
          else if(operator=='*') {
        	 
        	  System.out.println(num1*num2);
          }
          else if(operator=='/') {
        	  
        	  System.out.println(num1/num2);
          }
          else if(operator=='%') {
        	  System.out.println(num1%num2);
        	  
          }
          else {
        	  System.out.println("you enter wrong key");
          }
         
          
         
          
          
          
		
		
	}

}
