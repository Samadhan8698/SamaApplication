package coding;

public class Method {

	String city;

    // method with return type with no arguments

     void setCity(String c) {
        city=c;
    }

    String getCity() {
        return city;
    }
}
