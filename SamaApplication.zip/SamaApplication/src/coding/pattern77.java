package coding;

public class pattern77 {
	public static void main(String[] args) {
		
       int size=5;
		
		for(int i=1; i<=size; i++)
		{
			System.out.print(i+" ");
			for(int j=2,k=4,p=i; j<=i; j++,k--)
			{ 
				p=p+k;
				System.out.print(p+" ");	
		}
		
			System.out.println();
		
	}
	}
}


