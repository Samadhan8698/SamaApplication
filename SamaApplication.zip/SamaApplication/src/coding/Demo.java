package coding;

public class Demo {

	public static void main(String[] args) {
		
//		int[] a = {10, 20, 30, 40, 50, 60, 70, 80, 90};
//		
//		int min=a[0];
//		
//		for(int i=0;i<a.length;i++) {
//		
//			 if(a[i]>min) {
//				
//				 min=a[i];
//			 }
//			 
//		}
//		System.out.println(min);
		
		for(int j=1;j<=100;j++) {
		int count=0;
	
		
		for(int i=1;i<=j;i++) {
		
			  if(j%i==0) {
				 
				 count++;
			  }
		}
		if(count==2) {
		
			System.out.println(j);
		}
	}

	}
}

