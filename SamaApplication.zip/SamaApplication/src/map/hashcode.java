package map;

import java.util.HashMap;

public class hashcode {

	public static void main(String[] args) {
		
		HashMap<Integer, String> hm = new HashMap<Integer,String>();
		hm.put(1, "888");
		hm.put(2, "abc");
		
		//System.out.println(hm.get(1).hashCode()%11);
         hm.containsKey(1);
         System.out.println(hm.containsKey(2));
	}

}
