package map;

import java.util.HashMap;

public class fetch_data {

	public static void main(String[] args) {
		

		HashMap<Integer,String> m2 = new HashMap<Integer,String>();
		  m2.put(4, "abc");
		  m2.put(1, "abc");
		  m2.put(2, "xyz");
		  m2.put(3, null);
		  m2.put(null, null);
	
		  
		  System.out.println(m2);
		  // search element from map
		  System.out.println(m2.get(1));
		  
		 // remove or delete from map
		  System.out.println(m2.remove(2));
		  System.out.println(m2);
		  
		  // is empty or not
		  if(m2.isEmpty()) {
			  System.out.println("true");
		  }
		  else {
			 System.out.println("false"); 
		  }
		  
		  // convert into next HashMap
		  
		  HashMap<Integer,String> m3 = new HashMap<Integer,String>(m2);
		  System.out.println(m3);
		  
		  // key is present or not
		  System.out.println(m3.get(5));
		  
		  // replace element
		  m3.replace(1, "lmn");
		  System.out.println(m3);
		  
//		  m3.keySet();
//		  System.out.println(m3);
		  
		  
		  
	}

}
