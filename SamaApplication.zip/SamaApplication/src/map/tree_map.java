package map;

import java.util.TreeMap;

public class tree_map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TreeMap<Integer,String> tm = new TreeMap();
		tm.put(6, "xyz");
		tm.put(3, "abc");
		tm.put(2, "lmn");
		tm.put(3, "abc updated");
		
		System.out.println(tm);
		
		// properties of tree map
		// map help us to store data in key value pair
		// tree data structure helping us to maintain ascending order of keys
		// if you repeat a particular key its wont show an exception it will updated the value 
		// of that particular key
		// Non-Synchronidsed (support multi-threading_)
		
		

	}

}
