package map;

import java.util.TreeMap;

public class great_key_Small {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TreeMap<Integer,String> tm = new TreeMap();
		tm.put(6, "xyz");
		tm.put(3, "abc");
		tm.put(2, "lmn");
		tm.put(1, "abc updated");
		
		System.out.println("greatest key : "+tm.lastKey());
		System.out.println("least key : "+tm.firstKey());
		
		// to check key exist or not
		// value exist or not
		
		System.out.println(tm.containsKey(2));
		System.out.println(tm.containsValue("abc"));
		
		// write a programme to get the greatest key less than equal to the given key
		
		System.out.println(tm.floorKey(8));
		System.out.println(tm.floorEntry(8));

	}

}
