package map;

import java.util.HashMap;
import java.util.Map;

public class basic_map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		
//		  Map m1 = new HashMap();
//		  m1.put(1, "abc");
//		  m1.put(2, "xyz");
//		  m1.put(3, null);
//		  m1.put(null, null);
//		  m1.put(4, "abc");
//		  
//		  System.out.println(m1);
//		  
		  
		  HashMap<Integer,String> m2 = new HashMap<Integer,String>();
		  m2.put(4, "abc");
		  m2.put(1, "abc");
		  m2.put(2, "xyz");
		  m2.put(3, null);
		  m2.put(null, null);
	
		  
		  System.out.println(m2);
		  
		  
	}

}
