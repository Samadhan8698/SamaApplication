package map;

import java.util.TreeMap;

public class sorted_key_order {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TreeMap<Integer,String> tm = new TreeMap();
		tm.put(6, "xyz");
		tm.put(3, "abc");
		tm.put(2, "lmn");
		tm.put(1, "abc updated");
		
		System.out.println(tm);
		
		for(Integer i : tm.keySet()) {
			
			System.out.println(i);
		}

	}

}
