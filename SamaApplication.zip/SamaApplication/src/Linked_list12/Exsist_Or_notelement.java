package Linked_list12;

import java.util.LinkedList;

public class Exsist_Or_notelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList<Integer> l1 = new LinkedList<Integer>();
		l1.add(40);
		l1.add(30);
		l1.add(20);
		l1.add(10);
		
		System.out.println(l1);
		
		
		LinkedList<Integer> l12 = new LinkedList<Integer>();
		l12.add(40);
		l12.add(30);
		l12.add(20);
		l12.add(20);
	
		
		System.out.println(l12);
		
		// particular element exist in LinkedList
		System.out.println(l1.contains(30));
		
		// compare two linked list
		
		System.out.println(l1.containsAll(l12));
		
		// alternate to contains method
		
		System.out.println(l1.equals(l12));

	}

}
