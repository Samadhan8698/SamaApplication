package Linked_list12;


import java.util.Iterator;
import java.util.LinkedList;



public class Iterate_All_ele {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList<Integer> List=new LinkedList();
		
		List.add(10);
		List.add(20);
		List.add(30);
		List.add(40);
		
		System.out.println(List);
		Iterator i = List.listIterator();
		
		while(i.hasNext()) {
			System.out.println(i.next()+ " ");
		}
		

	}

}
