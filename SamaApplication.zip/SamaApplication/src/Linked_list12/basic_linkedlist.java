package Linked_list12;
import java.util.*;

public class basic_linkedlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		LinkedList l1 = new LinkedList();
		l1.offer(10);
		l1.offer(20);
		l1.offer(30);
		l1.offer(40);
		l1.offerFirst(60);
		l1.offerLast(100);
		
		System.out.println(l1);
	}

}
