package Linked_list12;

import java.util.*;

public class convert_Linked_to_array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		LinkedList L1 = new LinkedList();
		L1.offer(10);
		L1.offer(20);
		L1.offer(30);
		L1.offer(40);
		
		System.out.println(L1);
		System.out.println(L1.getClass());
		
		ArrayList a1 = new ArrayList(L1);
		System.out.println(a1);
		System.out.println(a1.getClass());
		
		
		
	}

}
