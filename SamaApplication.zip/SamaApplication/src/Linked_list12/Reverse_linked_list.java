package Linked_list12;

import java.util.Iterator;
import java.util.LinkedList;

public class Reverse_linked_list {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedList<Integer> l1 = new LinkedList<Integer>();
		l1.add(40);
		l1.add(30);
		l1.add(20);
		l1.add(10);
		
		Iterator i = l1.descendingIterator();
		
		while(i.hasNext()) {
			
			System.out.println(i.next());
		}
		
		
	}

}
