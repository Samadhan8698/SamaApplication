package Linked_list12;

import java.util.LinkedList;

public class linkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList<Integer> l1 = new LinkedList<Integer>();
		l1.add(40);
		l1.add(30);
		l1.add(20);
		l1.add(10);
		l1.offer(60);
		l1.offer(90);
		
		System.out.println(l1);
		// remove specified element from linked list
		System.out.println(l1.remove(1));
		System.out.println(l1);
		
		//remove first
		// remove last
		// removeAll
		

	}

}
