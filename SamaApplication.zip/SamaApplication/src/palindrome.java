

class myclass2 {
	void palindrome(int num) {
		
		int sum=0;
		int rem=0;
		int temp=num;
		
		while(num>0) {
			rem=num%10;
			sum=sum*10+rem;
			num=num/10;
			
		}
		if(temp==sum) {
			System.out.println("palindrome number");
		}
		else {
			System.out.println("not palindrome number");
		}
	}
	
	void countdigit(int number) {
		int count=0;
		
		while(number>0) {
			number=number/10;
			count++;
		}
		System.out.println("count of digit :"+count);
	}
	void sumofdigit(int n) {
		int sum=0;
		int rem=0;
		while(n>0) {
			rem=n%10;
			sum=sum+rem;
			n=n/10;
		}
		System.out.println("sum of digit :"+sum);
	}
	
}


public class palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        myclass2 a=new myclass2();
        a.palindrome(123);
        a.countdigit(23);
        a.sumofdigit(23);
	}

}
