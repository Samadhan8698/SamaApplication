package CF;
import java.util.*;

public class Remove_all_element {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList <Integer> List = new LinkedList();
		List.offer(10);
		List.offer(10);
		List.offer(10);
		List.offer(10);
		List.offer(10);
		
		System.out.println(List);
		
		List.clear();
		System.out.println(List);
		

	}

}
