package CF;

import java.util.ArrayList;
import java.util.Collections;

public class Sort_reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList <Integer> List1 = new ArrayList();
		
		List1.add(20);
		List1.add(30);
		List1.add(10);
		List1.add(40);
		
		System.out.println(List1);
		
		Collections.sort(List1,Collections.reverseOrder());
		System.out.println("Descending order : "+List1);

	}

}
