package CF;
import java.util.*;
import java.util.ArrayList;

public class Shraddha {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <Integer> List = new ArrayList();
		List.add(10);
		List.add(20);
		System.out.println(List);
		

	}

}
