package CF;

import java.util.ArrayList;

public class Arrlist_to_Another_Arrlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList <Integer> List1 = new ArrayList();
		
		List1.add(10);
		List1.add(20);
		List1.add(30);
		
	System.out.println(List1);
		
		ArrayList <Integer> List2 = new ArrayList(List1);
		System.out.println(List2);
		

	}

}
