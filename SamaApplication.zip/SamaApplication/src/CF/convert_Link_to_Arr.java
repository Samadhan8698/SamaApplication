package CF;
import java.util.*;

public class convert_Link_to_Arr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// convert linked list into array list.
		
		LinkedList <Integer> List = new LinkedList();
		
		List.offer(10);
		List.offer(20);
		List.offer(30);
		List.offer(40);

		
		ArrayList <Integer> List1 = new ArrayList(List);
		System.out.println(List1);

	}

}
