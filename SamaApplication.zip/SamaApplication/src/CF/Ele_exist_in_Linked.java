package CF;
import java.util.*;

public class Ele_exist_in_Linked {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// element exist in linked list or not
		LinkedList <Integer> List = new LinkedList();
		
		List.offer(10);
		List.offer(20);
		List.offer(30);
		List.offer(40);
		
//		System.out.println(List);
		
		int element = 100;
		if(List.contains(element)) {
			System.out.println(true);
		}
		else {
			System.out.println(false);
		}

	
		

	}

}
