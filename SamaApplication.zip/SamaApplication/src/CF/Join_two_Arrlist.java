package CF;

import java.util.ArrayList;

public class Join_two_Arrlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <Integer> List1 = new ArrayList();
		
		List1.add(20);
		List1.add(30);
		List1.add(10);
		List1.add(40);
		
		ArrayList <Integer> List2 = new ArrayList();
		
		List1.add(200);
		List1.add(300);
		List1.add(100);
		List1.add(400);
		
		ArrayList <Integer> List3 = new ArrayList();
		
		List3.addAll(List1);
		List3.addAll(List2);
		System.out.println(List3);
		
	}

}
