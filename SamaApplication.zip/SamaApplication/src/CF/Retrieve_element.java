package CF;
import java.util.*;

public class Retrieve_element {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList <Integer> List = new LinkedList();
		List.offer(10);
		List.offer(20);
		List.offer(30);
		List.offer(40);
		
		System.out.println(List);
		
		System.out.println(List.peek());
		System.out.println(List.peekFirst());
		System.out.println(List.peekLast());
		System.out.println(List);
		

	}

}
