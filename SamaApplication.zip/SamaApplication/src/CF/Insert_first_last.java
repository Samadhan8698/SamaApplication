package CF;

import java.util.*;

public class Insert_first_last {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList <Integer> List = new LinkedList();
		List.offer(10);
		List.offer(20);
		List.offer(80);
		List.offer(25);
		List.offer(85);
		
		System.out.println("element at index 2: "+List.get(2));
		System.out.println();
		System.out.println("first element: "+List.getFirst());
		System.out.println();
		System.out.println("Last element: "+List.getLast());

	}

}
