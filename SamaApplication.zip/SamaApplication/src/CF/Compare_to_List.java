package CF;

//import java.util.ArrayList;
import java.util.*;

public class Compare_to_List {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList <Integer> List1 = new ArrayList();
		
		List1.add(10);
		List1.add(20);
		List1.add(30);
	
		
		ArrayList <Integer> List2 = new ArrayList();
		
		List2.add(10);
		List2.add(30);
		List2.add(20);
		
		int cnt=0;
		
		for(Integer i : List1) {
			if(List2.contains(i)) {
				cnt++;
			}
		}
		if(cnt==List1.size()) {
			System.out.println(true);
		}
		else {
			System.out.println(false);
		}

	}

}
