package CF;
import java.util.*;
import java.util.ArrayList;

public class InsertElement2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList <Integer> List = new ArrayList();
		
		int index=3;
		
		List.add(10);
		List.add(20);
		List.add(30);
		List.add(40);
		List.add(50);
		List.add(60);
		List.add(100);
		System.out.println(List);
		
		List.add(index,888);
		System.out.println(List);
      
	}

}
