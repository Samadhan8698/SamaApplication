package CF;
import java.util.*;

public class Join_two_linked_list {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList <Integer> List1 = new LinkedList();
		List1.offer(10);
		List1.offer(20);
		List1.offer(80);
		System.out.println(List1);
		
		LinkedList <Integer> List2 = new LinkedList();
		List2.offer(10);
		List2.offer(20);
		List2.offer(80);
		System.out.println(List2);
		
		LinkedList <Integer> List3 = new LinkedList();
		List3.addAll(List1);
		List3.addAll(List2);
		
		System.out.println(List3);

	}

}
