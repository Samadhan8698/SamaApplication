package CF;

import java.util.ArrayList;
import java.util.Collections;

public class Sort_ArrList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList <Integer> List1 = new ArrayList();
		
		List1.add(30);
		List1.add(10);
		List1.add(40);
		List1.add(20);
		
		System.out.println("Input : "+List1);
		Collections.sort(List1);
		System.out.println("Ascending order : "+List1);
		
		

	}

}
