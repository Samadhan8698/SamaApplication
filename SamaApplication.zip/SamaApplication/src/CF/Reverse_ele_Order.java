package CF;

import java.util.ArrayList;
import java.util.Collections;

public class Reverse_ele_Order {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <Integer> List = new ArrayList();
		
		List.add(70);
		List.add(10);
		List.add(80);
		List.add(40);
		
		System.out.println(List);
		Collections.reverse(List);
		System.out.println(List);

	}

}
