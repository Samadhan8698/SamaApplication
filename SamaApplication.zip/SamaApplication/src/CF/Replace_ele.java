package CF;
import java.util.*;

public class Replace_ele {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	// replace an element in a linked list
		
		LinkedList <Integer> List = new LinkedList();
		
		List.offer(10);
		List.offer(20);
		List.offer(30);
		List.offer(40);

		System.out.println(List);
		System.out.println();
		
		List.set(0, 80);
		System.out.println(List);

	}

}
