package CF;
import java.util.*;

public class Element_position {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// wtite  a programe to display the element and their position in linked list
		
		LinkedList <Integer> List = new LinkedList();
		List.offer(10);
		List.offer(20);
		List.offer(80);
		List.offer(25);
		List.offer(85);
		
		for(int i=0;i<List.size();i++) {
			System.out.println(List.get(i) + ": " + i);
		}
	}

}
