package CF;

import java.util.Iterator;
import java.util.LinkedList;

public class Insert_ele_first_last_posi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
             // insert element first and last position at linkedlist
		
		LinkedList<Integer> List = new LinkedList();
		List.offer(10);
		List.offer(20);
		List.offer(30);
		List.offerFirst(85);
		List.offerLast(75);
	
		
		Iterator i = List.listIterator(0);
		while(i.hasNext()) {
			System.out.println(i.next());
		}
	}

}
