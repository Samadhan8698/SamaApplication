package CF;
import java.util.*;
import java.util.ArrayList;

public class Remove_from_arraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <String> List = new ArrayList();
		
		List.add("abc");
		List.add("fgc");
		List.add("xyz");
		
		System.out.println(List);
		
		int index=2;
		List.remove(index);
		System.out.println(List);

	}

}
