package CF;

import java.util.*;

public class clone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList <Integer> List1 = new LinkedList();
		List1.offer(10);
		List1.offer(20);
		List1.offer(80);
		
		LinkedList <Integer> List2 = new LinkedList(List1);
		System.out.println(List2);
		
		// remove and return the first element of a linked list
		
		System.out.println(List2.pop());

	}

}
